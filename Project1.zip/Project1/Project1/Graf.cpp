/*#include "Graf.h"



Graf::Graf()
{
}


Graf::~Graf()
{
}

template<typename V, typename H>
static void Graf::napojit(Vrchol<V, H>* a, Vrchol<V, H>* b, Hrana<V, H>* h)
{
	h->v1 = a;
	h->v2 = b;

	int pozice = a.najdiVolnouPoziciVPoli();
	a.hrany[pozice] = h;
	
	int pozice = b.najdiVolnouPoziciVPoli();
	b.hrany[pozice] = h;
}*/