#pragma once
//#ifndef PRUCHODGRAFEM_H
//#define PRUCHODGRAFEM_H
#include "Vrchol.h"
#include "Hrana.h"


template<typename V, typename H>
class PruchodGrafem
{
public:
	PruchodGrafem() {
	
	
	};
	~PruchodGrafem()
	{

	}

	static bool jeDosazitelny(Vrchol<V, H>* a, Vrchol<V, H>* b) {
		Vrchol<V, H> * zasobnik[LIMIT];
		Vrchol<V, H> * poleDosazenychVrcholu[LIMIT];
		for (int i = 0; i < LIMIT; i++)
		{
			zasobnik[i] = nullptr;
			poleDosazenychVrcholu[i] = nullptr;
		}

		zasobnik[0] = a;


		for (int i = 0; i < LIMIT; i++)
		{
			if (zasobnik[i] == nullptr) {
				return false;
			}
			if (zasobnik[i] == b) {
				return true;
			}
			else if(!bylNavsiven(zasobnik[i], poleDosazenychVrcholu)){
				int pozice = najdiVolnouPoziciVPoli(poleDosazenychVrcholu);
				poleDosazenychVrcholu[pozice] = zasobnik[i];
					
					for (int y = 0; y < LIMIT; y++)
					{
						Hrana<int, int> * h = zasobnik[i]->hrany[y];
						
						if (h != nullptr)
						{
							Vrchol<V, H>* opacnyVrchol = h->dejOpacnouStranu(zasobnik[i]);
							int volnaPozice = najdiVolnouPoziciVPoli(zasobnik);
							zasobnik[volnaPozice] = opacnyVrchol;
						}

					}
			}
				
		}
		return false;
	}

private:

	static bool bylNavsiven(Vrchol<V,H>* a, Vrchol<V, H>** poleDosazenychVrcholu) {
		for (int i = 0; i < LIMIT; i++)
		{
			if (poleDosazenychVrcholu[i] != nullptr && poleDosazenychVrcholu[i] == a) {
				return true;
			}
		}
		return false;
	}

	static int najdiVolnouPoziciVPoli(Vrchol<V, H>** poleDosazenychVrcholu) {
		for (int i = 0; i < LIMIT; i++)
		{
			if (poleDosazenychVrcholu[i] == nullptr)
			{
				return i;
			}
		}
	}
};





//#endif // !PRUCHODGRAFEM_H
