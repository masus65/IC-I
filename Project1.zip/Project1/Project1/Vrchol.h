#pragma once
#include "Hrana.h"
//#ifndef VRCHOL_H
//#define VRCHOL_H

//#define LIMIT 100;

const int LIMIT = 100;

template<typename V, typename H> 
 class Vrchol
{
public:
	V data;
	Hrana<V, H> * hrany[LIMIT];

	Vrchol() 
	{
		for (int i = 0; i < LIMIT; i++)
		{
			hrany[i] = nullptr;
		}
	};
	~Vrchol() {

	}

	int najdiVolnouPoziciVPoli() {
		for (int i = 0; i < LIMIT; i++)
		{
			if (hrany[i] == nullptr)
			{
				return i;
			}
		}

	}

private:

};


//#endif // !VRCHOL_H

