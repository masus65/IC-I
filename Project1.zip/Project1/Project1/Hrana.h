#pragma once
#include "Vrchol.h"
//#ifndef HRANA_H
//#define HRANA_H

template<typename V, typename H>
class Vrchol;

template<typename V, typename H>
class Hrana	
{
public:
	H data;
	Vrchol<V,H> * v1 ;
	Vrchol<V,H> * v2;


	Hrana() {
		v1 = nullptr;
		v2 = nullptr;
	};
	~Hrana()
	{

	}

	Vrchol<V, H> * dejOpacnouStranu(Vrchol<V, H> * v) {
		if (v==v1)
		{
			return v2;
		}
		else if (v == v2) {
			return v1;
		}
		throw "vrchol nepatri k hrane";
	};

private:

};





//#endif // !HRANA_H

