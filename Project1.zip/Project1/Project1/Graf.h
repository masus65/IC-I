#pragma once
#include "Vrchol.h"
#include "Hrana.h"

//#ifndef GRAF_H
//#define	GRAF_H


class Graf
{
public:
	Graf();
	~Graf();


	template<typename V, typename H>
	static void napojit(Vrchol<V, H>* a, Vrchol<V, H>* b, Hrana<V, H>* h)
	{
		h->v1 = a;
		h->v2 = b;

		int pozice = a->najdiVolnouPoziciVPoli();
		a->hrany[pozice] = h;

		int pozice2 = b->najdiVolnouPoziciVPoli();
		b->hrany[pozice2] = h;
	}
};

//#endif // !GRAF_H

