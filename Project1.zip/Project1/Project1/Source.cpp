#include "Vrchol.h"
#include "Hrana.h"
#include "Graf.h"
#include "PruchodGrafem.h"
#include <iostream>




using namespace std;

int main() {
	
	Vrchol<int, int> v1;
	Vrchol<int, int> v2;
	Vrchol<int, int> v3;
	Vrchol<int, int> v4;
	Vrchol<int, int> v5;
	Vrchol<int, int> v6;
	Vrchol<int, int> v7;
	Vrchol<int, int> v8;
	Hrana<int, int> h1;
	Hrana<int, int> h2;
	Hrana<int, int> h3;
	Hrana<int, int> h4;
	Hrana<int, int> h5;
	Hrana<int, int> h6;
	Hrana<int, int> h7;

	
	Graf::napojit(&v1, &v2, &h1);
	Graf::napojit(&v2, &v3, &h2);
	Graf::napojit(&v3, &v4, &h3);
	Graf::napojit(&v4, &v5, &h4);
	Graf::napojit(&v5, &v6, &h5);
	Graf::napojit(&v2, &v5, &h6);
	Graf::napojit(&v7, &v8, &h7);

	bool vysledek = PruchodGrafem<int, int>::jeDosazitelny(&v1, &v6);
	bool vysledek2 = PruchodGrafem<int, int>::jeDosazitelny(&v1, &v7);
	bool vysledek3 = PruchodGrafem<int, int>::jeDosazitelny(&v2, &v5);
	bool vysledek4 = PruchodGrafem<int, int>::jeDosazitelny(&v4, &v7);

	cout << "je dosazitelny: " << vysledek << endl;
	cout << "je dosazitelny: " << vysledek2 << endl;
	cout << "je dosazitelny: " << vysledek3 << endl;
	cout << "je dosazitelny: " << vysledek4 << endl;
}